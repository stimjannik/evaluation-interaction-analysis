#!/bin/bash
config_dir='config_default'

java_args="-Xmx8g -jar build/libs/evaluation-interaction-analysis-0.1.0-SNAPSHOT-all.jar"
fjar_args="--config ${config_dir}/general.properties,${config_dir}"

args="${java_args} ${fjar_args}"

./gradlew clean build

java ${args}/clean.properties
java ${args}/prepare.properties
java ${args}/interactions_01.properties
java ${args}/interactions_02.properties
java ${args}/interactions_03.properties
java ${args}/interactions_04.properties
java ${args}/run.properties

cur_results_dir=$(<"results/.current")
rm  ${cur_results_dir}.zip 2> /dev/null
zip -r -q -o ${cur_results_dir}.zip results/${cur_results_dir}
